API_TOKEN = '5908201624:AAGxbx6iZhNrha30IDxtaJN_1VOSNldcq98'

Tarif = "Orol muommosini yechishga o'z hissangizni qo'shing"
jam = "🌎 Orol dengizini asrash uchun hissamizni qo'shaylik 🌎"

jamgarma = "Jamg'arma uchun 💸"
orol = "Orol holatini ko'rish 👁"
about = "📖 Orol haqida 📖"
tarqat = "Yuborish📲"


link = "https://t.me/orol_jamgarmasi_bot?start=177222093883"

abouts = "«Orol fojiasining ilk sabablari nimada? Men bu masalada ko‘plab mutaxassislar, " \
         "olimlar va ekspertlarning fikri bilan tanishman. Aytish lozimki, bu — nihoyatda " \
         "murakkab mavzu. Ba’zan ushbu masala bo‘yicha bahs boshlansa, his-tuyg‘ularga berilib" \
         " ketish ham kuzatiladi. O‘z vaqtida u, menimcha, haddan tashqari siyosiylashtirib yuborilgan " \
         "edi.Xo‘sh, fojiaga o‘zi nima olib keldi? Buni tushunish uchun, keling, his-tuyg‘ularni bir " \
         "chetga surib, oddiy dalillarga murojaat qilaylik. Xaritaga qarang. Sirdaryoni olsak," \
         " u Tojikiston, O‘zbekiston va Qozog‘iston hududlaridan oqib o‘tadi. Lekin daryo oqimining " \
         "­deyarli to‘rtdan uch qismi Қирғизис­тонda shakllanadi, ya’ni muzliklar erishidan hosil " \
         "bo‘lgan Qoradaryo va Norin daryolarining qo‘shilishidan Sirdaryo tashkil topadi. ­Amudaryo " \
         "oqimining 80 foizi esa Tojikiston va Afg‘onistondagi tog‘larda vujudga keladi. Shundan keyin bu " \
         "daryo O‘zbekiston va Afg‘oniston chegarasi bo‘ylab oqadi, Turkmanistonning shimoli-sharqiy" \
         " qismini kesib o‘tib, yana O‘zbekiston hududida oqishni davom ettiradi. Hattoki, bugungi global " \
         "isish va muzliklar erishi sharoitida ham Orolni to‘ldirib turgan bu ikki daryoning suvi uni saqlab " \
         "qolish uchun yetgan bo‘lar edi, — dedi u.«Endi tarixga nazar tashlasak. O‘tgan asrning" \
         " 60-yillarida O‘rta Osiyoning barcha respublikalari va Qozog‘istonda jadal sur’atlar bilan" \
         " cho‘llarni o‘zlashtirish boshlandi. Yiliga 70 — 80 ming gektar yer o‘zlashtirilar edi." \
         " Bir gektar maydonni qishloq xo‘jaligida foydalanish uchun tayyorlash, u yerda hosil yetishtirishga" \
         " hech bo‘lmaganda o‘n va undan ortiq ming kub metr suv kerak bo‘ladi. Shunday qilib, " \
         "cho‘lni o‘zlashtirish uchun har yili 600 — 700 million, ba’zan bir milliard kub metrgacha" \
         " suv sarflanar edi. Sirdaryo va Amudaryodan suv olish hajmi yildan-yilga ortib bordi. Vaqti " \
         "kelib, daryolar endi Orolga yetib bormay qo‘ydi, bunday holat keyingi yillarda yuz berdi.Xo‘sh, " \
         "biz Orolni yo‘qotib qo‘yishimiz mumkinligini qachon tushunib yetdik? Aslida cho‘l yerlarni " \
         "keng ko‘lamda o‘zlashtirish natijasida daryolar suvi Orolga yetib bormasligi avvaldan ma’lum edi." \
         " Shuni bilgan holda, nega bo‘lmasa, bunchalik tez o‘zlashtirish va ko‘p suv sarfiga yo‘l qo‘yildi?" \
         "\n\n" \
         "👇 Orol tiklanishi haqida video 👇"